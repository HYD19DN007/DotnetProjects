﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Warehouse
    {
        string loc;

        public Warehouse(string loc)
        {
            this.loc = loc;
        }

        public string Loc { get => loc; }
    }
    class Item : Warehouse
    {
        int itemId;
        string iname;

        public Item(int itemId, string iname, string WK) : base(WK)
        {
            this.itemId = itemId;
            this.iname = iname;
        }

        public int ItemId { get => itemId; }
        public string Iname { get => iname; }
    }
    class Sales
    {
        public List<Item> List = new List<Item>();
        public void Additem(Item I2)
        {
            List.Add(I2);
        }
        public void FindAndReturnItem(int ID)
        {
            int i = 0;
            for (i = 0; i < List.Count; i++)
            {
                if (ID == List[i].ItemId)
                    break;
            }
            if (i == List.Count)
            {
                Console.WriteLine("Item doesn't exist by the given ID");
                Console.WriteLine(" ");
            }
            else
            {
                Console.WriteLine("Item removed successfully");
                Console.WriteLine("Deleted Item is:");
                Console.WriteLine("Item no: " + List[i].ItemId + "Item name: " + List[i].Iname + "Location: " + List[i].Loc);
                List.RemoveAt(i);
                Console.WriteLine("");
            }

        }

    }
    class mainclass
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Console.Write("Do you want to enter data?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            //Console.WriteLine(ch);
            while (ch == 'Y')
            {
                Console.Write("Enter Item ID: ");
                int it = int.Parse(Console.ReadLine());
                Console.Write("Enter Item Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Warehouse Location: ");
                string loc1 = Console.ReadLine();
                Item I1 = new Item(it, name, loc1);
                S.Additem(I1);
                Console.WriteLine("");
                Console.Write("Do you want to enter data?(Y/N): ");
                ch = char.Parse(Console.ReadLine());

            }
            Console.WriteLine("");
            Console.Write("Please enter the Item ID you wish to delete: ");
            int Itemid = int.Parse(Console.ReadLine());
            S.FindAndReturnItem(Itemid);
            Console.WriteLine("");
            Console.ReadLine();
        }
    }
}
