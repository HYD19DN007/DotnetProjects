﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maincls.ctsTest
{
    class Warehouse
    {
        string loc;

        public Warehouse(string loc)
        {
            this.loc = loc;
        }

        public string Loc { get => loc; }
    }
    class Item : Warehouse
    {
        int itemId;
        string iname;

        public Item(int itemId, string iname, string Warehouse) : base(Warehouse)
        {
            this.itemId = itemId;
            this.iname = iname;
        }

        public int ItemId { get => itemId; }
        public string Iname { get => iname; }
    }
    class Sales
    {
        public List<Item> Lt = new List<Item>();
        public void AddItem(Item I2)
        {
            Lt.Add(I2);
        }
        public void FindAndReturnItem(int ID)
        {
            int i = 0;
            for (i = 0; i < Lt.Count; i++)
            {
                if (ID == Lt[i].ItemId)
                    break;
            }
            if (i == Lt.Count)
            {
                Console.WriteLine("Item doesn't exist");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("removed successfully");
                Console.WriteLine("Deleted Item detail:");
                Console.WriteLine("Item no: " + Lt[i].ItemId + "\tItem name: " + Lt[i].Iname + "\tLocation: " + Lt[i].Loc);
                Lt.RemoveAt(i);
                Console.WriteLine();
            }

        }

    }
    
    class question1main
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Console.Write("enter data?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            while (ch == 'Y' || ch == 'y')
            {
                Console.Write("Enter Item ID: ");
                int item = int.Parse(Console.ReadLine());
                Console.Write("Enter Item Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Warehouse Location: ");
                string location = Console.ReadLine();
                Item It = new Item(item, name, location);
                S.AddItem(It);
                Console.WriteLine();
                Console.Write("enter again?(Y/N): ");
                ch = char.Parse(Console.ReadLine());

            }
            Console.WriteLine();
            Console.Write("enter the Item ID  to delete: ");
            int Iid = int.Parse(Console.ReadLine());
            S.FindAndReturnItem(Iid);
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
