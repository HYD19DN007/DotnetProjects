﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.assignment3
{ 
        class warehouse
        {
            public warehouse(string location)
            {
                WarehouseLocation = location;
            }
            public string WarehouseLocation
            {
                get;
            }
        }
        class Item : warehouse
        {
            public Item(string location, int itemid, string itemname) : base(location)
            {
                ItemID = itemid;
                ItemName = itemname;
            }
            public int ItemID
            {
                get;
            }
            public string ItemName
            {
                get;
            }
        }
        class sales
        {

            List<Item> l = new List<Item>();

            public void AddItem(Item I)
            {
                l.Add(I);


            }
            
            public Item FindandReturnItem(int itemno)
            {
                Item item = null;
                for (int i = 0; i < l.Count; i++)
                {
                    if (l[i].ItemID == itemno)
                    {

                        item = l[i];
                        l.Remove(l[i]);
                        return item;
                    }
                }
                throw new exceptionex("item not found");



            }
        }

       
}

