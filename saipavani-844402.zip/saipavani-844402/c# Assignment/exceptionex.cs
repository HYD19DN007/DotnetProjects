﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.assignment3
{
    class exceptionex: Exception
    {
      
            public exceptionex(string s) : base(s)
            {

            }
        
    }
}
