﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace demo
    {
        class Program
        {
            static void Main(string[] args)
            {
                SqlConnection con = null;
                SqlDataAdapter adp = null;
                DataSet ds = null;
                con = new SqlConnection("Integrated Security =SSPI;Persist Security Info=False;Initial Catalog=demo;Data Source=DESKTOP-P8I8NIK");
                adp = new SqlDataAdapter("select product_id,product_name,description,standard_cost,list_price from productinfo where product_id=@d", con);
            Console.WriteLine("Enter ProductID");
                adp.SelectCommand.Parameters.AddWithValue("@d", int.Parse(Console.ReadLine()));
                ds = new DataSet();
                adp.Fill(ds, "e");
                DataRow r = ds.Tables["e"].Rows[0];
                Console.WriteLine(r[1]);
                Console.WriteLine(r[2].ToString());
                Console.WriteLine(r[3].ToString());
                Console.WriteLine(r[4].ToString());
                Console.Read();




            }
        }
    }

