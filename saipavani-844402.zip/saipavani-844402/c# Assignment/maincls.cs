﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.assignment3
{
    class maincls
    {
       
            static void Main(string[] args)
            {
                sales s = new sales();
                Console.WriteLine("do you want to enter item ");
                char ch = char.Parse(Console.ReadLine());
                while (ch == 'y' || ch == 'Y')
                {
                Console.WriteLine("Enter location");
                Console.WriteLine("Enter itemid");
                Console.WriteLine("Enter itemname");
                Item it = new Item(Console.ReadLine(), int.Parse(Console.ReadLine()), Console.ReadLine());
                    s.AddItem(it);
                    Console.WriteLine("do you want to enter one more item ");
                    ch = char.Parse(Console.ReadLine());
                }
                try
                {
                    Item i1 = s.FindandReturnItem(1);
                    Console.WriteLine("Returned item is: ");
                    Console.WriteLine("location: " + i1.WarehouseLocation + "itemid: " + i1.ItemID + "itemname: " + i1.ItemName);
                }
                catch (exceptionex e)
                {
                    Console.WriteLine(e.Message);
                }


                Console.Read();
            }
        }
    }


