﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment.csharp1stquestion
{
    class warehouse
    {
         
        
        string WarehouseLocation;

        public warehouse(string warehouseLocation)
        {
            WarehouseLocation = warehouseLocation;
        }
        public string WarehouseLocation1 { get => WarehouseLocation; }
    }
    class Item : warehouse
    {
        int ItemID;
        string ItemName;

        public Item(int itemID, string itemName, string location) : base(location)
        {
            ItemID = itemID;
            ItemName = itemName;
        }

        public int ItemID1 { get => ItemID; }
        public string ItemName1 { get => ItemName; }
    }
    class Sales
    {
        List<Item> list_of_items = null;
        public Sales()
        {
            list_of_items = new List<Item>();
        }
        public void AddItem(Item i)
        {
            list_of_items.Add(i);

        }
        public Item FindandReturnItem(int item_no)
        {
            for (int i = 0; i < list_of_items.Count; i++)
            {
                if (list_of_items[i].ItemID1 == item_no)
                {
                    Item it = list_of_items[i];
                    list_of_items.Remove(list_of_items[i]);
                    return it;
                }

            }
            throw new Exception("Item not found");
        }
    }
}
