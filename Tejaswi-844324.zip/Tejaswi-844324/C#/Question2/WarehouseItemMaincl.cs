﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsDemo.Test
{
    class Warehouse
    {
        string WarehouseLocation;

        public Warehouse(string warehouseLocation)
        {
           this.WarehouseLocation = warehouseLocation;
        }

       
        public string WarehouseLocation1 { get => WarehouseLocation;  }
    }
    class Item : Warehouse
    {
        int itemId;
        string itemname;

        public int ItemId1 { get => itemId; }
        public string Itemname { get => itemname;  }

        public Item(string WarehoseLocation, int itemid, string itemName) : base(WarehoseLocation)
        {
            this.itemId = itemid;
            itemname = itemName;
        }

    }
    class Sales
    {
        List<Item> l = new List<Item>();
        public void AddItem(Item i1)
        {
            l.Add(i1);
           

        }

        public Item FindandReturnItem(int Itemno)
        {
           
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].ItemId1 == Itemno)
                {
                    Item t = l[i];
                    l.Remove(l[i]);

                    return t;
                }
            }
            throw new Exception("Item not found");
        }
       


    }
    class WarehouseItemMaincl
    {
        static void Main(string[] args)
        {


            Sales s = new Sales();

            Item i1 = null;
            Console.Write("Do you want to Add Item?(Y/N): ");
            char ch1 = char.Parse(Console.ReadLine());
            while (true)
            {

               
                if (ch1 == 'Y' || ch1 == 'y')
                {
                    Console.WriteLine("Enter work location");
                    string loc = Console.ReadLine();
                    Console.Write("Enter Itemno:");
                    int ItemId = int.Parse(Console.ReadLine());
                    Console.Write("Enter ItemName:");
                    string ItemName = Console.ReadLine();
                    i1 = new Item(loc, ItemId, ItemName);
                    s.AddItem(i1);
                    Console.Write("Do you want to Add an Item?(Y/N): ");
                    ch1 = char.Parse(Console.ReadLine());
                }
                else
                    break;


            }
            
                try
                {
                    Console.WriteLine("Enter item number to delete");
                    int k = int.Parse(Console.ReadLine());
                    Item item = s.FindandReturnItem(k);
                    Console.WriteLine("ItemId :" + item.ItemId1 + " ItemName " + item.Itemname + " Location " + item.WarehouseLocation1);
                    Console.WriteLine("Deleted Item :" + item.Itemname);
                    
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            Console.Read(); 

            
            
            
        }
    }
}
