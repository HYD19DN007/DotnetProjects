﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace OopsDemo.Test
{
   
    class question5
    {

        SqlConnection con = null;
        SqlDataAdapter adp = null;
        static void Main(string[] args)
        {
            question5 c = new question5();
            Console.WriteLine("Enter Product_Id to retrive");
            int pid = int.Parse(Console.ReadLine());
            c.Print(pid);
            Console.Read();

        }
        public void Print(int pid)
        {
            try
            {
                con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Practical;Data Source=DESKTOP-D0JPLOI");
                adp = new SqlDataAdapter("select *from Productinfo where product_id=@pid", con);
                adp.SelectCommand.Parameters.AddWithValue("@pid", pid);
                DataSet ds = new DataSet();
                adp.Fill(ds, "T");
                DataRow r = ds.Tables["T"].Rows[0];
                Console.WriteLine("ProductId " + r[0] + "\n Product_Name " + r[1] + "\n Description " + r[2] + "\n Standard_Cost " + r[3] + "\n List_price " + r[4]);
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
   
}
