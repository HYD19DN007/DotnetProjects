﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSDemo.practicals
{
    class customexception:Exception
    {
        public customexception(string s):base(s)
        { }
    }
    class warehouse
    {
        public warehouse(string loc)
        {
            WarehouseLocation = loc;
        }
        public string WarehouseLocation
        {
            get;
        }
    }
    class Item:warehouse
    {
        public Item(string loc,int itemid,string itemname):base(loc)
        {
            ItemID = itemid;
            ItemName = itemname;
        }
        public int ItemID
        {
            get;
        }
        public string ItemName
        {
            get;
        }
    }
    class sales
    {
      
        List<Item> l=new List<Item>();

        public void AddItem(Item I)
        {
            l.Add(I);
            
           
        }
        
        public Item FindandReturnItem(int itemno)
        {
            Item item = null;
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].ItemID == itemno)
                {

                    item = l[i];
                    l.Remove(l[i]);
                    return item;
                }
            }
            throw new customexception("item not found");
            


        }
    }

    class Maincls
    {
        static void Main(string[] args)
        {
            sales s = new sales();
            Console.WriteLine("do you want to enter item ");
            char ch = char.Parse(Console.ReadLine());
            while(ch=='y'||ch=='Y')
            {
                Console.WriteLine("Enter loc,itemid,itemname");
                Item i = new Item(Console.ReadLine(), int.Parse(Console.ReadLine()), Console.ReadLine());
                s.AddItem(i);
                Console.WriteLine("do you want to enter one more item ");
                ch = char.Parse(Console.ReadLine());
            }
            try
            {
                Item i1 = s.FindandReturnItem(1);
                Console.WriteLine("Returned item is");
                Console.WriteLine("loc - " + i1.WarehouseLocation + "\titemid - " + i1.ItemID + "\titemname - " + i1.ItemName);
            }
            catch(customexception e)
            {
                Console.WriteLine(e.Message);
            }
            
            
            Console.Read();
        }
    }
}
