﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace OOPSDemo.practicals
{
    class Q2
    {
        

        static void Main(string[] args)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Assignment;Data Source=DESKTOP-0RKU0Q0");
                Console.WriteLine("Enter Product_id");

                con.Open();
                cmd = new SqlCommand("select * from productinfo where product_id=@p", con);
                cmd.Parameters.AddWithValue("@p", Console.ReadLine());
                SqlDataReader r = cmd.ExecuteReader();

                if (r.Read())
                {

                    Console.Write("Product_id is - ");
                    Console.WriteLine(r[0]);
                    Console.Write("Product_name is - ");
                    Console.WriteLine(r[1]);
                    Console.Write("Description is - ");
                    Console.WriteLine(r[2]);
                    Console.Write("Standard Cost is - ");
                    Console.WriteLine(r[3]);
                    Console.Write("List_price is - ");
                    Console.WriteLine(r[4]);

                }
                else
                {
                    Console.WriteLine("No product id exists");
                }
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(SqlException e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                con.Close();
            }

            Console.Read();
        }
    }
    

}
