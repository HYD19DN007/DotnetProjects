﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSdemo.C_Sharp_Prog
{
    class TheMain
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Console.Write("Do you want to enter data?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            //Console.WriteLine(ch);
            while (ch == 'Y')
            {
                Console.Write("Enter Item ID: ");
                int it = int.Parse(Console.ReadLine());
                Console.Write("Enter Item Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Warehouse Location: ");
                string loc1 = Console.ReadLine();
                Item I1 = new Item(it, name, loc1);
                S.Additem(I1);
                Console.WriteLine("-----------------------------------------------");
                Console.Write("Do you want to enter data?(Y/N): ");
                ch = char.Parse(Console.ReadLine());
                
            }
            Console.WriteLine("-----------------------------------------------");
            Console.Write("Please enter the Item ID you wish to delete: ");
            int Itemid = int.Parse(Console.ReadLine());
            S.FindAndReturnItem(Itemid);
            Console.WriteLine("-----------------------------------------------");
            Console.ReadLine();
        }
    }
}
