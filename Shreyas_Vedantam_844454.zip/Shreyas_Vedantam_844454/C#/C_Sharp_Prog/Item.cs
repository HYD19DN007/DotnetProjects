﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSdemo.C_Sharp_Prog
{
    class Item : Warehouse
    {
        int itemId;
        string iname;

        public Item(int itemId, string iname, string WK) : base(WK)
        {
            this.itemId = itemId;
            this.iname = iname;
        }

        public int ItemId { get => itemId; }
        public string Iname { get => iname; }
    }
}
