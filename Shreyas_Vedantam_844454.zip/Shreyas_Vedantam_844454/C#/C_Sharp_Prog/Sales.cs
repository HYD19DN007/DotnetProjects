﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSdemo.C_Sharp_Prog
{
    class Sales
    {
        public List<Item> L = new List<Item>();
        public void Additem(Item I2)
        {
            L.Add(I2);
        }
        public void FindAndReturnItem(int ID)
        {
            int i=0;
            for(i = 0; i < L.Count; i++)
            {
                if (ID == L[i].ItemId)
                    break;
            }
            if (i == L.Count)
            {
                Console.WriteLine("Item doesn't exist by the given ID");
                Console.WriteLine("-----------------------------------------------");
            }
            else
            {
                Console.WriteLine("Item removed successfully");
                Console.WriteLine("Deleted Item is:");
                Console.WriteLine("Item no: " + L[i].ItemId + "\nItem name: " + L[i].Iname + "\nLocation: " + L[i].Loc);
                L.RemoveAt(i);
                Console.WriteLine("-----------------------------------------------");
            }
            
        }
        
    }
}
