﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSdemo.ADONet
{
    class AdoNetConsole
    {
        static void Main(string[] args)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            Console.Write("Please Enter the Product ID: ");
            int PID = int.Parse(Console.ReadLine());
            try
            {
                con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Practical;Data Source=DESKTOP-K3VHFUJ");
                con.Open();
                cmd = new SqlCommand("select product_id,product_name,description,standard_cost,list_price from productinfo where product_id=@id", con);
                cmd.Parameters.AddWithValue("@id", PID);
                SqlDataReader R = cmd.ExecuteReader();
                R.Read();
                Console.WriteLine("Product ID : " + R[0]);
                Console.WriteLine("Product Name : " + R[1]);
                Console.WriteLine("Description : " + R[2]);
                Console.WriteLine("Standard Cost : " + R[3]);
                Console.WriteLine("List Price : " + R[4]);
            }
            catch (InvalidOperationException E)
            {
                Console.WriteLine("Invalid Product ID.");
            }
            finally
            {
                con.Close();
            }
            Console.ReadLine();
        }
    }
}
