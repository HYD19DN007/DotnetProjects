﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsDemo.ctstest
{
    class Warehouse
    {
        string loc;

        public Warehouse(string loc)
        {
            this.loc = loc;
        }

        public string Loc { get => loc; }
    }
}
