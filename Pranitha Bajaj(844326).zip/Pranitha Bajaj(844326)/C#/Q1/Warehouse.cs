﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops.Test
{
    class Warehouse
    {
        string WareHouseLocation;
        public string WareHouseLocation1 { get; }
        public Warehouse(string wareHouseLocation)
        {
            WareHouseLocation = wareHouseLocation;
        }

    }
    class Item:Warehouse
    {
        public int ItemID { get ;  }
        public string ItemName { get ;  }

        public Item(int itemID, string itemName,string wareHouseLocation):base(wareHouseLocation)
        {
            ItemID = itemID;
            ItemName = itemName;
        }

       
    }
    class Sales
    {
        List<Item> l = null;
        public Sales()
        {
            l = new List<Item>();
        }
        public void AddItem(Item i)
        {
            l.Add(i);

        }
        public Item FindandReturnItem(int item_no)
        {
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].ItemID == item_no)
                {
                    Item it = l[i];
                    l.Remove(l[i]);
                    return it;
                }

            }
            throw new Exception("Item not found");
        }
        
    }
}
