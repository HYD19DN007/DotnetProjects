﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Oops
{
    class Test
    {
        SqlConnection Con = null;
        SqlCommand Cmd = null;
        int product_id;
        public Test(int product_id)
        {
            this.product_id = product_id;
        }
        public int Product_id { get => product_id; }
        public void test()
        {
            try
            {
                Con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Demo;Data Source=DESKTOP-583QKG1");
                Con.Open();
                Cmd = new SqlCommand("select product_id,product_name,description,standard_cost,list_price from productinfo where product_id=@Pid", Con);
                Cmd.Parameters.AddWithValue("@Pid", Product_id);
                SqlDataReader R = Cmd.ExecuteReader();
                R.Read();
                Console.WriteLine("PRODUCT_ID : " + R[0]);
                Console.WriteLine("PRODUCT_NAME : " + R[1]);
                Console.WriteLine("DESCRIPTION : " + R[2]);
                Console.WriteLine("STANDARD_COST : " + R[3]);
                Console.WriteLine("LIST_PRICE : " + R[4]);
            }
            catch (InvalidOperationException E)
            {
                Console.WriteLine("Enter Valid Product_id");
            }
            finally
            {
                Con.Close();
            }
        }
    
        static void Main(string[] args)
        {
            Console.Write("Enter Product ID : ");
            int pid = int.Parse(Console.ReadLine());
            Test T=new Test(pid);
            T.test();
            Console.Read();
        }
    }
}
