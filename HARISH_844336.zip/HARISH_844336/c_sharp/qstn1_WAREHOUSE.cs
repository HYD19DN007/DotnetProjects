﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSdemo.warehouse
{
    class Warehouse1
    {
        string location1;

        public Warehouse1(string location1)
        {
            this.location1 = location1;
        }

        public string Location1 { get => location1; }
    }
    class Item : Warehouse1
    {
        int itemid;
        string itemname;

        public Item(int itemid, string itemname, string ware) : base(ware)
        {
            this.itemid = itemid;
            this.itemname = itemname;
        }

        public int Itemid { get => itemid; }
        public string Itemname { get => itemname; }
    }
    class Sales
    {
        public List<Item> L = new List<Item>();
        public void Additem(Item I2)
        {
            L.Add(I2);
        }
        public void FindAndReturnItem(int itemid1)
        {
            int i = 0;
            for (i = 0; i < L.Count; i++)
            {
                if (itemid1 == L[i].Itemid)
                    break;
            }
            if (i == L.Count)
            {
                Console.WriteLine("item not existed with this id");
                Console.WriteLine("___________");
            }
            else
            {
                Console.WriteLine("item deleted");
                Console.WriteLine("deleted item is:");
                Console.WriteLine("Item no_____: " + L[i].Itemid);
              
                Console.WriteLine("Item name___: " + L[i].Itemname);
                Console.WriteLine("Location____: " + L[i].Location1);
                L.RemoveAt(i);
                Console.WriteLine("___________");
            }

        }

    }
    class TheMain
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Console.Write("do u want to enter data _?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            //Console.WriteLine(ch);
            while (ch == 'Y' || ch== 'y')
            {
                Console.Write("enter item id - ");
                int it = int.Parse(Console.ReadLine());
                Console.Write("enter item name- ");
                string name = Console.ReadLine();
                Console.Write("enter location ");
                string loc1 = Console.ReadLine();
                Item I = new Item(it, name, loc1);
                S.Additem(I);
                Console.WriteLine("___________");
                Console.Write("do u want to enter data _?(Y/N): ");
                ch = char.Parse(Console.ReadLine());

            }
            Console.WriteLine("___________");
            Console.Write("enter the item you want to delete ");
            int Itemid = int.Parse(Console.ReadLine());
            S.FindAndReturnItem(Itemid);
            Console.WriteLine("___________");
            Console.ReadLine();
        }
    }
}
