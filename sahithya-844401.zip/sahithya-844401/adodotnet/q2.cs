﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace oopsdemo
{

    class qs
    {
        static void Main(string[] args)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            Console.Write("Enter Product ID : ");
            int pid = int.Parse(Console.ReadLine());
            try
            {
                con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=assignment;Data Source=DESKTOP-U715LPE");
                con.Open();
                cmd = new SqlCommand("select product_id,product_name,description,standard_cost,list_price from productinfo where product_id=@Pid", con);
                cmd.Parameters.AddWithValue("@Pid", pid);
                SqlDataReader r = cmd.ExecuteReader();
                r.Read();
                Console.WriteLine("PRODUCT_ID : " + r[0]);
                Console.WriteLine("PRODUCT_NAME : " + r[1]);
                Console.WriteLine("DESCRIPTION : " + r[2]);
                Console.WriteLine("STANDARD_COST : " + r[3]);
                Console.WriteLine("LIST_PRICE : " + r[4]);
            }
            catch (InvalidOperationException )
            {
                Console.WriteLine("Enter Valid Product_id");
            }
            finally
            {
                con.Close();
            }
            Console.Read();
        }
    }
}    

