﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopesDemo.adodotnetconsole.Test
{
    class Warehouse
    {
        string WarehouseLocation;
        public Warehouse(string warehouseLocation)
        {
            WarehouseLocation = warehouseLocation;
        }
        public string WarehouseLocation1 { get => WarehouseLocation;}
    }
    class Item : Warehouse
    {
        int ItemID;
        string ItemName;
        public Item(int itemID, string itemName, string warehouseLocation) : base(warehouseLocation)
        {
            ItemID = itemID;
            ItemName = itemName;
        }

        public int ItemID1 { get => ItemID; }
        public string ItemName1 { get => ItemName;}
    }
    class Sales
    {
        List<Item> Li = new List<Item>();
        public void AddItem(Item I)
        {
            Li.Add(I);
        }
        public void FindAndReturnItem(int ItemID)
        {
            int i = 0;
            for (i = 0; i < Li.Count; i++)
            {
                if (ItemID == Li[i].ItemID1)
                    break;
            }
            if (i == Li.Count)
            {
                Console.WriteLine("Item doesn't exist by the given ID");
                Console.WriteLine("-----------------------------------------------");
            }
            else
            {
                Console.WriteLine("Item removed successfully");
                Console.WriteLine("Deleted Item is:");
                Console.WriteLine("Item ID: " + Li[i].ItemID1 + "\nItem Name: " + Li[i].ItemName1 + "\nWareHouse Location: " + Li[i].WarehouseLocation1);
                Li.RemoveAt(i);
                Console.WriteLine("-----------------------------------------------");
            }

        }
    }
    class csharpq1
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Item I = null;
            char ch = 'Y';
            while (ch == 'Y' || ch == 'y')
            {
                Console.Write("ItemID : ");
                int iid1 = int.Parse(Console.ReadLine());
                Console.Write("Item Name : ");
                string iname1 = Console.ReadLine();
                Console.Write("WareHouse Location : ");
                string warehouseloc1 = Console.ReadLine();
                I = new Item(iid1, iname1, warehouseloc1);
                S.AddItem(I);
                Console.WriteLine();
                Console.Write("Do you want to continue? (Y / N) : ");
                ch = char.Parse(Console.ReadLine());
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine();
            }
            Console.WriteLine("---------------------------------------------");
            Console.Write("Please enter the Item ID you wish to delete: ");
            int Itemid = int.Parse(Console.ReadLine());
            S.FindAndReturnItem(Itemid);
            Console.Read();
        }
    }
}
