﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.EXAMM
{
    class SALES1
    {
        public List<Items> l = new List<Items>();


        public void Additem(Items i)
        {
            l.Add(i);
        }
        public void FindandReturn(int itemID)
        {
            int i = 0;
            for (i = 0; i < l.Count; i++)
            {
                if (itemID == l[i].Itemid)
                    break;
            }
            if (i == l.Count)
            {
                Console.WriteLine("Item doesn't exist by the given ID");

            }
            else
            {
                Console.WriteLine("Item removed successfully");
                Console.WriteLine("Deleted Item is:");
                Console.WriteLine("Item no: " + l[i].Itemid + "\nItem name: " + l[i].Itemname + "\nLocation: " + l[i].Warehouselocation);
                l.RemoveAt(i);



            }

        }
    }
}

    

