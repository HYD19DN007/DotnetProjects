﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.EXAMM
{
    class MAINEXAM1
    {
        static void Main(string[] args)
        {
            SALES1 S = new SALES1();
            Console.Write("Do you want to enter data?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            //Console.WriteLine(ch);
            while (ch!='N')
            {
                Console.Write("Enter Item ID: ");
                int it = int.Parse(Console.ReadLine());
                Console.Write("Enter Item Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Warehouse Location: ");
                string loc1 = Console.ReadLine();
                Items I1 = new Items(it, name, loc1);
                S.Additem(I1);
               
                Console.Write("Do you want to enter data?(Y/N): ");
                ch = char.Parse(Console.ReadLine());

            }
            
            Console.Write("Please enter the Item ID you wish to delete: ");
            int Itemid = int.Parse(Console.ReadLine());
            S.FindandReturn(Itemid);
           
            Console.ReadLine();
        }
    }
}
