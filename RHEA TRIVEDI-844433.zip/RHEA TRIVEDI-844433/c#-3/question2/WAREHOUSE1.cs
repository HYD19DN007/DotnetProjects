﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsdemo.EXAMM
{
    class WAREHOUSE1
    {
      

            string warehouselocation;

            public WAREHOUSE1(string warehouselocation)
            {
                this.Warehouselocation = warehouselocation;
            }

            public string Warehouselocation { get => warehouselocation; set => warehouselocation = value; }



        }
        class Items : WAREHOUSE1
        {
            int itemid;
            string itemname;

            public Items(int itemid, string itemname, string loc) : base(loc)
            {
                this.Itemid = itemid;
                this.Itemname = itemname;
            }

            public int Itemid { get => itemid; set => itemid = value; }
            public string Itemname { get => itemname; set => itemname = value; }
        }


    }



