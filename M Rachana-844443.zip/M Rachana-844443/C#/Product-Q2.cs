﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace AdoNetConsole
{
    class Product
    {
        static void Main(string[] args)
        {

            SqlConnection Con = null;
            SqlDataAdapter Adp = null;
            DataSet DS = null;
            Con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Practical;Data Source=DESKTOP-FTR5U2I ");
            Adp = new SqlDataAdapter("select * from productinfo where product_id=@pno", Con);
            Console.WriteLine("Enter product id");
            Adp.SelectCommand.Parameters.AddWithValue("@pno", int.Parse(Console.ReadLine()));
            DS = new DataSet();
            Adp.Fill(DS, "E");
            DataRow R = DS.Tables["E"].Rows[0];
            Console.WriteLine(R[0]);
            Console.WriteLine(R[1]);
            Console.WriteLine(R[2]);
            Console.WriteLine(R[3]);
            Console.WriteLine(R[4]);



            Console.Read();

        }

    }
}
