﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace OOPsDemo.CSHARPASSIGNMENTS
{
    class CustomException:Exception
    {
        public CustomException(string s):base(s)
        {

        }
    }
    class Warehouse
    {
        string Warehouselocation;
        public Warehouse(string wareHouseLocation)
        {
            Warehouselocation = wareHouseLocation;
        }

        public string WareHouseLocation
        {
            get
            {
                return Warehouselocation;
            }
        }
    }

    class item : Warehouse
    {
        int ItemId;
        string Itemname;

        public item(int itemid,string itemname,string location):base(location)
        {
            ItemId = itemid;
            Itemname = itemname;
        }
        public int Itemid1
        {
            get
            {
                return ItemId;
            }
        }

        public string Itemname1
        {
            get
            {
                return Itemname;
            }
        }

    }

    class sales
    {
        List<item> item=new List<item>();

        public void Additem(item i)
        {
            item.Add(i);
        }

        public item FindAndReturnItem(int num)
        {
            item it = null;
            for(int i=0;i<item.Count;i++)
            {
                if(item[i].Itemid1==num)
                {
                    it= item[i];
                    item.Remove(item[i]);
                    
                }
            }
            return it;

        }
        
    }

    class Maincls
    {
        static void Main(string[] args)
        {
            sales s = new sales();
            Console.WriteLine("Enter Y");
           char ip= char.Parse(Console.ReadLine());
            while(ip=='Y')
            {
                Console.WriteLine("enter Item_id,Item_name,Location");
                item i = new item(int.Parse(Console.ReadLine()), Console.ReadLine(), Console.ReadLine());
                s.Additem(i);
                Console.WriteLine("Do you want to add one more item");
                ip= char.Parse(Console.ReadLine());
            }

            try
            {
                item op= s.FindAndReturnItem(1);

                Console.WriteLine("Returned item is:");
                Console.WriteLine("itemid: " + op.Itemid1 + " itemname: " + op.Itemname1 + " Location: " + op.WareHouseLocation);
                
            }

            catch(CustomException E)

            {
                Console.WriteLine(E.Message);
            }

            Console.Read();
        }
    }
}
