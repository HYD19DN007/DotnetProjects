﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oops.csharp
{
    class warehouse
    {
        public warehouse(string warehouselocation)
        {
            Warehouselocation = warehouselocation;
        }

        public string Warehouselocation { get; }
    }
    class Item:warehouse
    {
        public Item(int itemid, string itemname, string warehouselocation) :base(warehouselocation)
        {
            Itemid = itemid;
            Itemname = itemname;
        }

        public int Itemid { get;  }
        public string Itemname { get; }
    }
    class sales
    {
        List<Item> list_of_items = null;
        public sales()
        {
            list_of_items = new List<Item>();
        }
        public void AddItem(Item i)
        {
            list_of_items.Add(i);

        }
        public Item FindandReturnItem(int item_no)
        {
            for (int i = 0; i < list_of_items.Count; i++)
            {
                if (list_of_items[i].Itemid == item_no)
                {
                    Item it = list_of_items[i];
                    list_of_items.Remove(list_of_items[i]);
                    return it;
                }
            }
            throw new Exception("Item not found");
        }
    }
    class question2
    {
        static void Main(string[] args)
        {
            sales s = new sales();
            Item i = null;
            Console.WriteLine("Press y to add");
            string str;
            while (true)
            {
                str = Console.ReadLine();
                Console.WriteLine("Enter Item id , Name, Location");
                if (str == "y")
                {
                    int id = int.Parse(Console.ReadLine());
                    string name = Console.ReadLine();
                    string loc = Console.ReadLine();
                    i = new Item(id, name, loc);
                    s.AddItem(i);
                    Console.WriteLine("Press y to add and any key to stop adding");
                }
                else
                {
                    break;
                }
            }
            try
            {
                Console.WriteLine("Enter item number to delete");
                Item i1 = s.FindandReturnItem(int.Parse(Console.ReadLine()));
                Console.WriteLine("ItemId :" + i1.Itemid + " ItemName " + i1.Itemname + " Location " + i1.Warehouselocation);
                Console.WriteLine("Deleted Item :" + i1.Itemname);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.Read();
        }
    }
}
