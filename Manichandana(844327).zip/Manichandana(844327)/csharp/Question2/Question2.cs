﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace OopsDemo.ADO
{
    //Display the Product_Id,Product_Name,Description,Standard_Cost,List_price though ADO.NET 
    class Question2
    {

        SqlConnection con = null;
        SqlDataAdapter adp = null;
        static void Main(string[] args)
        {
            Question2 c = new Question2();
            Console.WriteLine("Enter Product_Id");
            int pid = int.Parse(Console.ReadLine());
            c.Print(pid);
            Console.Read();

        }
        public void Print(int pid)
        {
            try
            {
                con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ADODB;Data Source=DESKTOP-KGLF046");
                adp = new SqlDataAdapter("select *from Productinfo where product_id=@p", con);
                adp.SelectCommand.Parameters.AddWithValue("@p", pid);
                DataSet ds = new DataSet();
                adp.Fill(ds, "P");
                DataRow R = ds.Tables["P"].Rows[0];
                Console.WriteLine("ProductId " + R[0] + " Product_Name " + R[1] + " Description " + R[2] + " Standard_Cost " + R[3] + " List_price " + R[4]);
            }
            catch(SqlException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine("No Product found");
            }

        }
    }
}
