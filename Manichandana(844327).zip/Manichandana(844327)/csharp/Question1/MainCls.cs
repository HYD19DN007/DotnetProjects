﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsDemo.Question1
{
    class MainCls
    {
        static void Main(string[] args)
        {
            Sales s = new Sales();
            Item i = null;
            Console.WriteLine("Press y/Y to add");
            string str;
            while(true)
            {
                str = Console.ReadLine();
                
                if (str=="y" || str=="Y")
                {
                    Console.WriteLine("Enter Item id , Name, Location");
                    int id = int.Parse(Console.ReadLine());
                    string name = Console.ReadLine();
                    string loc = Console.ReadLine();
                    i = new Item(id, name, loc);
                    s.AddItem(i);
                    Console.WriteLine("Press y/Y to add and any key to stop adding");
                }
                else
                {
                    break;
                }

            }
            try
            {
                Console.WriteLine("Enter item number to delete");
                Item i1 = s.FindandReturnItem(int.Parse(Console.ReadLine()));
                Console.WriteLine("ItemId :" + i1.ItemID1+" ItemName "+i1.ItemName1+" Location "+i1.WarehouseLocation1);
                Console.WriteLine("Deleted Item :"+i1.ItemName1);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.Read();


        }
    }
}
