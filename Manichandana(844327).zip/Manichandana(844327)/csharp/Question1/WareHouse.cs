﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsDemo.Question1
{
    class WareHouse
    {
        string WarehouseLocation;

        public WareHouse(string warehouseLocation)
        {
            WarehouseLocation = warehouseLocation;
        }

        public string WarehouseLocation1 { get => WarehouseLocation; }
    }
}
