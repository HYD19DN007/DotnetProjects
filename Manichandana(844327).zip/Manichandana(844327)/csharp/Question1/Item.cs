﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsDemo.Question1
{
    class Item:WareHouse
    {
        int ItemID;
        string ItemName;

        public Item(int itemID, string itemName,string location):base(location)
        {
            ItemID = itemID;
            ItemName = itemName;
        }

        public int ItemID1 { get => ItemID; }
        public string ItemName1 { get => ItemName;}
    }
}
