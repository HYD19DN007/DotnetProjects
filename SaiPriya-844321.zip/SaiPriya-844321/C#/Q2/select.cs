﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace OopsDemo.Test1
{
    class select
    {
        SqlConnection con = null;
        SqlDataAdapter adp = null;
        static void Main(string[] args)
        {
           select c = new select();
            Console.WriteLine("Enter Product_Id");
            int pid = int.Parse(Console.ReadLine());
            c.Print(pid);
            Console.Read();

        }
        public void Print(int pid)
        {
            try
            {
                con = new SqlConnection("Password=Admin@123;Persist Security Info=True;User ID=sa;Initial Catalog=Test1;Data Source=DESKTOP-16F77EK");
                adp = new SqlDataAdapter("select *from Productinfo where product_id=@p", con);
                adp.SelectCommand.Parameters.AddWithValue("@p", pid);
                DataSet ds = new DataSet();
                adp.Fill(ds, "P");
                DataRow R = ds.Tables["P"].Rows[0];
                Console.WriteLine("ProductId " + R[0]);
                Console.WriteLine("Product_name" + R[1]);
                Console.WriteLine("Description" + R[2]);
                Console.WriteLine("Standard_Cost" + R[3]);
                Console.WriteLine("List_price" + R[4]);
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }

    }

