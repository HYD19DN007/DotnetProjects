﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsDemo.Ware_house_question
{
    class Warehouse
    {
        public string WHLocation1 { get; }

        public Warehouse(string WHLocation)
        {
            WHLocation1 = WHLocation;
        }


    }
    class Item : Warehouse
    {
        public int ItemID1 { get; }
        public string ItemName1 { get; }
        public Item(int itemID, string itemName, string WHLocation) : base(WHLocation)
        {
            ItemID1 = itemID;
            ItemName1 = itemName;
        }

    }
    class Sales
    {
        public List<Item> L = new List<Item>();
        public void Additem(Item I2)
        {
            L.Add(I2);
        }
        public void FindAndReturnItem(int k)
        {
            if (k < L.Count)
            {
                L.RemoveAt(k);
                Console.WriteLine("Item removed successfully");
                Console.WriteLine("Deleted Item is ");
                Console.WriteLine("Item no: " + L[k - 1].ItemID1 + "\nItem name: " + L[k - 1].ItemName1 + "\nLocation: " + L[k - 1].WHLocation1);

            }
            else
            {
                Console.WriteLine("Number out of Bounds... Enter valid input");

            }
        }
        public void Print()
        {
            for (int i = 0; i < L.Count; i++)
            {
                Console.WriteLine("Item no: " + L[i].ItemID1 + "\nItem name: " + L[i].ItemName1 + "\nLocation: " + L[i].WHLocation1);
            }
        }
    }
    class maincls
    {
        static void Main(string[] args)
        {
            Sales S = new Sales();
            Console.Write("Do you want to enter data?(Y/N): ");
            char ch = char.Parse(Console.ReadLine());
            while (ch == 'Y' || ch == 'y')
            {
                Console.Write("Enter Itemno:");
                int it = int.Parse(Console.ReadLine());
                Console.Write("Enter ItemName:");
                string name = Console.ReadLine();
                Console.WriteLine("Enter work location ");
                string loc1 = Console.ReadLine();
                Item I1 = new Item(it, name, loc1);
                S.Additem(I1);
                Console.Write("Do you want to enter data?(Y/N): ");
                ch = char.Parse(Console.ReadLine());
            }
            Console.Write("Do you want to Remove data?(Y/N): ");
            char ch1 = char.Parse(Console.ReadLine());
            while (ch1 == 'Y' || ch1 == 'y')
            {
                Console.Write("Enter Itemno you want to remove: ");
                int k = int.Parse(Console.ReadLine());
                S.FindAndReturnItem(k);
                Console.Write("Do you want to Remove data?(Y/N): ");
                ch1 = char.Parse(Console.ReadLine());
            }
            Console.WriteLine("Items in the List are ");
            S.Print();
            Console.ReadLine();

        }

    }
}

